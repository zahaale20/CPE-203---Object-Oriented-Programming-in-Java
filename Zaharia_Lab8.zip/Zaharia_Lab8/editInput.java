import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class editInput {

    private static final String outputFileName = "drawMe.txt";

    public static void writeModifiedInput(String input_file) {
        try (Stream<String> input_reader = Files.lines(Paths.get(input_file))) {
            BufferedWriter output_writer = new BufferedWriter(new FileWriter(outputFileName));
            String[] output = input_reader
                    .filter(x -> checkZ(x))
                    .map(x -> Arrays.stream(x.split(","))
                            .map(y -> scale(y))
                            .collect(Collectors.joining(", ")))
                    .map(x -> translate(x))
                    .toArray(String[]::new);
            for (String line : output) {
                output_writer.write(line + "\n");
            }
            output_writer.close();
        } catch (FileNotFoundException e) {
            System.out.println("FILE NOT FOUND :" + input_file);
        } catch (IOException e) {
            System.out.println("ERROR READING/WRITING FILE : " + input_file);
        }
    }

    private static boolean checkZ(String num) {
        return Double.parseDouble(num.split(",")[num.split(",").length - 1]) <= 2.0;
    }

    private static String scale(String num) {
        return Double.toString(Double.parseDouble(num) * 0.5);
    }

    private static String translate(String input_f) {
        String[] output = input_f.split(", ");
        output[0] = Double.toString(Double.parseDouble(output[0]) - 150.0);
        output[1] = Double.toString(Double.parseDouble(output[1]) - 37.0);
        return output[0] + ", " + output[1] + ", " + output[2];
    }
}
