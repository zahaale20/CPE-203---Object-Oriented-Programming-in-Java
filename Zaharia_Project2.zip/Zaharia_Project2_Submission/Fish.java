import processing.core.PImage;

import java.util.List;
import java.util.Random;


public class Fish implements MovingEntity {
    private static final String CRAB_KEY = "crab";
    private static final String CRAB_ID_SUFFIX = " -- crab";
    private static final int CRAB_PERIOD_SCALE = 4;
    private static final int CRAB_ANIMATION_MIN = 50;
    private static final int CRAB_ANIMATION_MAX = 150;

    private static final Random rand = new Random();
    private final String id;
    private final List<PImage> images;
    private final int imageIndex;
    private final int actionPeriod;
    private Point position;

    public Fish(String id, Point position, List<PImage> images, int actionPeriod) {
        this.id = id;
        this.position = position;
        this.images = images;
        this.imageIndex = 0;
        this.actionPeriod = actionPeriod;
    }

    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this,
                Activityy.createActivityAction(this, world, imageStore),
                this.actionPeriod);
    }

    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Point pos = this.position;

        world.removeEntity(this);
        scheduler.unscheduleAllEvents(this);

        Entity crab = world.createCrab(this.id + CRAB_ID_SUFFIX, pos,
                this.actionPeriod / CRAB_PERIOD_SCALE,
                CRAB_ANIMATION_MIN + rand.nextInt(CRAB_ANIMATION_MAX - CRAB_ANIMATION_MIN),
                imageStore.getImageList(CRAB_KEY));

        world.addEntity(crab);
        ((MovingEntity) crab).scheduleActions(scheduler, world, imageStore);
    }

    public Point getPosition() {
        return position;
    }

    public void setPosition(Point point) {
        this.position = point;
    }

    public List<PImage> getImages() {
        return images;
    }

    public String getId() {
        return id;
    }

    public int getImageIndex() {
        return imageIndex;
    }

    @Override
    public int getActionPeriod() {
        return actionPeriod;
    }
}