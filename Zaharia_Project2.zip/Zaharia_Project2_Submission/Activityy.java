public class Activityy implements Action {
    private final Entity entity;
    private final WorldModel world;
    private final ImageStore imageStore;

    public Activityy(Entity entity, WorldModel world, ImageStore imageStore) {
        this.entity = entity;
        this.world = world;
        this.imageStore = imageStore;
    }

    public static Activityy createActivityAction(Entity entity, WorldModel world, ImageStore imageStore) {
        return new Activityy(entity, world, imageStore);
    }

    public void executeAction(EventScheduler scheduler) {
        ((MovingEntity) this.entity).executeActivity(world, imageStore, scheduler);
    }

    public Entity getEntity() {
        return entity;
    }

    public WorldModel getWorld() {
        return world;
    }

    public ImageStore getImageStore() {
        return imageStore;
    }


}