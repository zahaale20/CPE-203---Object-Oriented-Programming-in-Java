public interface MovingEntity extends Entity {
    void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler);

    int getActionPeriod();

    void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore);
}