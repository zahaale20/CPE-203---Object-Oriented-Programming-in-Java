public interface AnimatedEntity extends Entity {
    void nextImage();

    int getAnimationPeriod();
}