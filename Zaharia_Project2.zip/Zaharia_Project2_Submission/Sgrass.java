import processing.core.PImage;

import java.util.List;
import java.util.Optional;
import java.util.Random;

public class Sgrass implements MovingEntity {

    private static final String FISH_KEY = "fish";
    private static final String FISH_ID_PREFIX = "fish -- ";
    private static final int FISH_CORRUPT_MIN = 20000;
    private static final int FISH_CORRUPT_MAX = 30000;

    private static final Random rand = new Random();
    private final String id;
    private Point position;
    private final List<PImage> images;
    private final int imageIndex;
    private final int actionPeriod;

    public Sgrass(String id, Point position, List<PImage> images, int actionPeriod) {
        this.id = id;
        this.position = position;
        this.images = images;
        this.imageIndex = 0;
        this.actionPeriod = actionPeriod;
    }

    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this,
                Activityy.createActivityAction(this, world, imageStore),
                this.actionPeriod);
    }

    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Point> openPt = world.findOpenAround(this.position);

        if (openPt.isPresent()) {
            Entity fish = world.createFish(FISH_ID_PREFIX + this.id, openPt.get(),
                    FISH_CORRUPT_MIN + rand.nextInt(FISH_CORRUPT_MAX - FISH_CORRUPT_MIN),
                    imageStore.getImageList(FISH_KEY));
            world.addEntity(fish);
            ((MovingEntity) fish).scheduleActions(scheduler, world, imageStore);
        }

        scheduler.scheduleEvent(this,
                Activityy.createActivityAction(this, world, imageStore),
                this.actionPeriod);
    }

    @Override
    public int getActionPeriod() {
        return actionPeriod;
    }

    public Point getPosition() {
        return position;
    }

    public void setPosition(Point point) {
        this.position = point;
    }

    public List<PImage> getImages() {
        return images;
    }

    public String getId() {
        return id;
    }

    public int getImageIndex() {
        return imageIndex;
    }
}