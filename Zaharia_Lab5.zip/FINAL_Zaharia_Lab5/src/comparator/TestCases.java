package comparator;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class TestCases {
    private static final Song[] songs = new Song[]{
            new Song("Lil Uzi Vert", "Erase Your Social", 2016),
            new Song("A$AP Rocky", "L$D", 2014),
            new Song("Drake", "Champagne Poetry", 2021),
            new Song("Lil Uzi Vert", "Demon High", 2021),
            new Song("Travis Scott", "Mamacita", 2010),
            new Song("Future", "Too Comfortable", 2020),
            new Song("Gunna", "Too Easy", 2021),
            new Song("Don Toliver", "Get Throwed", 2021)
    };

    @Test
    public void testArtistComparator() {
        Song[] test0 = new Song[]{songs[0], songs[7]};
        Arrays.sort(test0, new ArtistComparator());
        Song[] result0 = new Song[]{songs[7], songs[0]};
        assertEquals(test0, result0);

        Song[] test1 = new Song[]{songs[6], songs[7]};
        Arrays.sort(test1, new ArtistComparator());
        Song[] result1 = new Song[]{songs[7], songs[6]};
        assertEquals(test1, result1);

        Song[] test2 = new Song[]{songs[3], songs[4]};
        Arrays.sort(test2, new ArtistComparator());
        Song[] result2 = new Song[]{songs[3], songs[4]};
        assertEquals(test2, result2);
    }

    @Test
    public void testLambdaTitleComparator() {
        Comparator<Song> compareTitle = (Song s1, Song s2) -> s1.getTitle().compareTo(s2.getTitle());

        Song[] test0 = new Song[]{songs[2], songs[7]};
        Arrays.sort(test0, compareTitle);
        Song[] result0 = new Song[]{songs[2], songs[7]};
        assertEquals(test0, result0);

        Song[] test1 = new Song[]{songs[0], songs[1]};
        Arrays.sort(test1, compareTitle);
        Song[] result1 = new Song[]{songs[0], songs[1]};
        assertEquals(test1, result1);

        Song[] test2 = new Song[]{songs[1], songs[6]};
        Arrays.sort(test2, compareTitle);
        Song[] result2 = new Song[]{songs[1], songs[6]};
        assertEquals(test2, result2);
    }

    @Test
    public void testYearExtractorComparator() {
        Comparator<Song> compareYear = Comparator.comparing(Song::getYear, (s1, s2) -> s2.compareTo(s1));

        Song[] test0 = new Song[]{songs[2], songs[7]};
        Arrays.sort(test0, compareYear);
        Song[] result0 = new Song[]{songs[2], songs[7]};
        assertEquals(test0, result0);

        Song[] test1 = new Song[]{songs[7], songs[3]};
        Arrays.sort(test1, compareYear);
        Song[] result1 = new Song[]{songs[7], songs[3]};
        assertEquals(test1, result1);

        Song[] test2 = new Song[]{songs[0], songs[5]};
        Arrays.sort(test2, compareYear);
        Song[] result2 = new Song[]{songs[5], songs[0]};
        assertEquals(test2, result2);
    }

    @Test
    public void testComposedComparator() {
        Comparator<Song> compareYear = Comparator.comparing(Song::getYear, (s1, s2) -> s1.compareTo(s2));
        Comparator<Song> compareTitle = (Song s1, Song s2) -> s1.getTitle().compareTo(s2.getTitle());
        Comparator<Song> artistThenYear = new ComposedComparator(new ArtistComparator(), compareYear);
        Comparator<Song> titleThenArtist = new ComposedComparator(compareTitle, new ArtistComparator());
        Comparator<Song> yearThenTitle = new ComposedComparator(compareYear, compareTitle);

        //artist then year
        Song[] songList0 = new Song[]{songs[3], songs[7]};
        Arrays.sort(songList0, artistThenYear);
        Song[] expected0 = new Song[]{songs[7], songs[3]};
        assertEquals(expected0, songList0);

        //title then artist
        Song[] songList2 = new Song[]{songs[5], songs[3]};
        Arrays.sort(songList2, titleThenArtist);
        Song[] expected2 = new Song[]{songs[3], songs[5]};
        assertEquals(expected2, songList2);

        //year then title
        Song[] songList3 = new Song[]{songs[1], songs[0]};
        Arrays.sort(songList3, yearThenTitle);
        Song[] expected3 = new Song[]{songs[1], songs[0]};
        assertEquals(expected3, songList3);
    }

    @Test
    public void testThenComparing() {
        Comparator<Song> test3 = Comparator.comparing(Song::getTitle, (s1, s2) -> s1.compareTo(s2))
                .thenComparing(new ArtistComparator());

        Song[] list1 = new Song[]{songs[0], songs[1]};
        Arrays.sort(list1, test3);
        Song[] list2 = new Song[]{songs[0], songs[1]};
        assertEquals(list2, list1);
    }

    @Test
    public void runSort() {
        // lambda comparator -> compares artists,
        // then titles if artists are the same,
        // then year if artists and titles are the same
        Comparator<Song> test3 = Comparator.comparing(Song::getArtist, (s1, s2) -> s1.compareTo(s2))
                .thenComparing(Song::getTitle, (s1, s2) -> s1.compareTo(s2))
                .thenComparing(Song::getYear, (s1, s2) -> s1.compareTo(s2));

        List<Song> songList = new ArrayList<>(Arrays.asList(songs));
        List<Song> expectedList = Arrays.asList(new Song("A$AP Rocky", "L$D", 2014),
                new Song("Don Toliver", "Get Throwed", 2021),
                new Song("Drake", "Champagne Poetry", 2021),
                new Song("Future", "Too Comfortable", 2020),
                new Song("Gunna", "Too Easy", 2021),
                new Song("Lil Uzi Vert", "Demon High", 2021),
                new Song("Lil Uzi Vert", "Erase Your Social", 2016),
                new Song("Travis Scott", "Mamacita", 2010));

        songList.sort(test3);
        assertEquals(songList, expectedList);
    }
}
