import processing.core.PImage;

import java.util.List;

public abstract class AnimatedEntity extends ActiveEntity {
    protected int animationPeriod;

    public AnimatedEntity(String id, List<PImage> images, Point position, int actionPeriod, int animationPeriod) {
        super(id, position, images, actionPeriod);
        this.animationPeriod = animationPeriod;
    }

    public PImage getCurrentImage()
    {
        return images.get(this.imageIndex);
    }

    public int getAnimationPeriod()
    {
        return this.animationPeriod;
    }

    public void nextImage()
    {
        this.imageIndex = (this.imageIndex + 1) % this.images.size();
    }

    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore)
    {
        ActivityAction activity = new ActivityAction(this, world, imageStore);
        AnimationAction animation = new AnimationAction(this, 0);
        scheduler.scheduleEvent(this, activity, actionPeriod );
        scheduler.scheduleEvent(this, animation, this.animationPeriod);
    }
}