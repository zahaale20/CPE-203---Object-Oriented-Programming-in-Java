import processing.core.PImage;

import java.util.List;

public class Atlantis extends AnimatedEntity {

    public static final int ATLANTIS_ANIMATION_REPEAT_COUNT = 7;

    public Atlantis(String id, List<PImage> images, Point position, int actionPeriod, int animationPeriod) {
        super(id, images, position, actionPeriod, animationPeriod);
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        scheduler.unscheduleAllEvents(this);
        world.removeEntity(this);
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, new AnimationAction(this, ATLANTIS_ANIMATION_REPEAT_COUNT), actionPeriod);
    }
}