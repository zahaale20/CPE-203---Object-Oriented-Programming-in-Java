import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class WorkSpace {
    private final List<Shape> shapes;

    public WorkSpace() {
        this.shapes = new ArrayList<>();
    }

    public void add(Shape shape) {
        shapes.add(shape);
    }

    public Shape get(int index) {
        return shapes.get(index);
    }

    public int size() {
        return shapes.size();
    }

    public List<Circle> getCircles() {
        List<Circle> c_list = new ArrayList<>();
        for (Shape i : shapes) {
            if (i instanceof Circle) {
                c_list.add((Circle) i);
            }
        }
        return c_list;
    }

    public List<Rectangle> getRectangles() {
        List<Rectangle> r_list = new ArrayList<>();
        for (Shape i : shapes) {
            if (i instanceof Rectangle) {
                r_list.add((Rectangle) i);
            }
        }
        return r_list;
    }

    public List<Triangle> getTriangles() {
        List<Triangle> t_list = new ArrayList<>();
        for (Shape i : shapes) {
            if (i instanceof Triangle) {
                t_list.add((Triangle) i);
            }
        }
        return t_list;
    }

    public List<ConvexPolygon> getConvexPolygons() {
        List<ConvexPolygon> cp_list = new ArrayList<>();
        for (Shape i : shapes) {
            if (i instanceof ConvexPolygon){
                cp_list.add((ConvexPolygon) i);
            }
        }
        return cp_list;
    }

    public List<Shape> getShapesByColor(Color color) {
        List<Shape> s_list = new ArrayList<>();
        for (Shape i : shapes) {
            if (i.getColor().equals(color))
                s_list.add(i);
        }
        return s_list;
    }

    public double getAreaOfAllShapes() {
        double result = 0;
        for (Shape i : shapes) {
            result += i.getArea();
        }
        return result;
    }

    public double getPerimeterOfAllShapes() {
        double result = 0;
        for (Shape i : shapes) {
            result += i.getPerimeter();
        }
        return result;
    }
}