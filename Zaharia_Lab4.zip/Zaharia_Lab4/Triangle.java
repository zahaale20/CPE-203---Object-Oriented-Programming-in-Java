import java.awt.*;

public class Triangle implements Shape {
    private final Point vertexA;
    private final Point vertexB;
    private final Point vertexC;
    private Color color;

    public Triangle(Point vertexA, Point vertexB, Point vertexC, Color color) {
        this.vertexA = vertexA;
        this.vertexB = vertexB;
        this.vertexC = vertexC;
        this.color = color;
    }

    public Point getVertexA() {
        return vertexA;
    }

    public Point getVertexB() {
        return vertexB;
    }

    public Point getVertexC() {
        return vertexC;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public double getArea() {
        return Math.abs(vertexA.getX() * (vertexB.getY() - vertexC.getY()) +
                vertexB.getX() * (vertexC.getY() - vertexA.getY()) +
                vertexC.getX() * (vertexA.getY() - vertexB.getY())) / 2;
    }

    public double getPerimeter() {
        double AB = Math.pow(Math.pow(vertexB.getX() - vertexA.getX(), 2) + Math.pow(vertexB.getY() - vertexA.getY(), 2), 0.5);
        double BC = Math.pow(Math.pow(vertexC.getX() - vertexB.getX(), 2) + Math.pow(vertexC.getY() - vertexB.getY(), 2), 0.5);
        double AC = Math.pow(Math.pow(vertexC.getX() - vertexA.getX(), 2) + Math.pow(vertexC.getY() - vertexA.getY(), 2), 0.5);
        return AB + BC + AC;
    }

    public void translate(Point point) {
        vertexA.setLocation(vertexA.getX() + point.getX(), vertexA.getY() + point.getY());
        vertexB.setLocation(vertexB.getX() + point.getX(), vertexB.getY() + point.getY());
        vertexC.setLocation(vertexC.getX() + point.getX(), vertexC.getY() + point.getY());
    }
}