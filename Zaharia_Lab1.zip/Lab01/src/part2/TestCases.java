package part2;

import org.junit.jupiter.api.Test;
import part1.Course;
import part1.CourseGrade;
import part1.Extracurricular;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.stream.Collectors;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class TestCases {
    /*
     * This test is just to get you started.
     */
    @Test
    public void testGetName()   {
        // This will not compile until you implement the Applicant class
        List<CourseGrade> grades = Arrays.asList(
                new CourseGrade(new Course("Intro to CS", 4), 100),
                new CourseGrade(new Course("Data Structures", 4), 95),
                new CourseGrade(new Course("Algorithms", 4), 91),
                new CourseGrade(new Course("Computer Organization", 4), 91),
                new CourseGrade(new Course("Operating Systems", 4), 75),
                new CourseGrade(new Course("Non-CS", 4), 83)
        );
        List<Extracurricular> extracurriculars = Arrays.asList(
                new Extracurricular("Engineering Club", 290),
                new Extracurricular("Robotics", 500),
                new Extracurricular("Tennis", 47),
                new Extracurricular("Computer Science Club", 403)
        );

        Applicant testApplicant = new Applicant("Aakash", grades, extracurriculars);

        // tests 1 & 2: applicant name
        assertEquals("Aakash", testApplicant.getName());
        assertNotEquals("Alex", testApplicant.getName());

    }

    @Test
    public void testGetGrades()   {
        // This will not compile until you implement the Applicant class
        List<CourseGrade> grades = Arrays.asList(
                new CourseGrade(new Course("Intro to CS", 4), 100),
                new CourseGrade(new Course("Data Structures", 4), 95),
                new CourseGrade(new Course("Algorithms", 4), 91),
                new CourseGrade(new Course("Computer Organization", 4), 91),
                new CourseGrade(new Course("Operating Systems", 4), 75),
                new CourseGrade(new Course("Non-CS", 4), 83)
        );
        List<Extracurricular> extracurriculars = Arrays.asList(
                new Extracurricular("Engineering Club", 290),
                new Extracurricular("Robotics", 500),
                new Extracurricular("Tennis", 47),
                new Extracurricular("Computer Science Club", 403)
        );

        Applicant testApplicant = new Applicant("Aakash", grades, extracurriculars);

        // tests 3 & 4: applicant grades
        assertEquals(grades, testApplicant.getGrades());
        assertNotEquals(extracurriculars, testApplicant.getGrades());

    }

    @Test
    public void testGetGradeFor()   {
        // This will not compile until you implement the Applicant class
        List<CourseGrade> grades = Arrays.asList(
                new CourseGrade(new Course("Intro to CS", 4), 100),
                new CourseGrade(new Course("Data Structures", 4), 95),
                new CourseGrade(new Course("Algorithms", 4), 91),
                new CourseGrade(new Course("Computer Organization", 4), 91),
                new CourseGrade(new Course("Operating Systems", 4), 75),
                new CourseGrade(new Course("Non-CS", 4), 83)
        );
        List<Extracurricular> extracurriculars = Arrays.asList(
                new Extracurricular("Engineering Club", 290),
                new Extracurricular("Robotics", 500),
                new Extracurricular("Tennis", 47),
                new Extracurricular("Computer Science Club", 403)
        );

        Applicant testApplicant = new Applicant("Aakash", grades, extracurriculars);

        // tests 5 & 6: applicant grade for a specific class
        assertEquals(100, testApplicant.getGradeFor("Intro to CS").getScore());
        assertNotEquals(15, testApplicant.getGradeFor("Non-CS").getScore());

    }

    @Test
    public void testGetExtracurriculars()   {
        // This will not compile until you implement the Applicant class
        List<CourseGrade> grades = Arrays.asList(
                new CourseGrade(new Course("Intro to CS", 4), 100),
                new CourseGrade(new Course("Data Structures", 4), 95),
                new CourseGrade(new Course("Algorithms", 4), 91),
                new CourseGrade(new Course("Computer Organization", 4), 91),
                new CourseGrade(new Course("Operating Systems", 4), 75),
                new CourseGrade(new Course("Non-CS", 4), 83)
        );
        List<Extracurricular> extracurriculars = Arrays.asList(
                new Extracurricular("Engineering Club", 290),
                new Extracurricular("Robotics", 500),
                new Extracurricular("Tennis", 47),
                new Extracurricular("Computer Science Club", 403)
        );

        Applicant testApplicant = new Applicant("Aakash", grades, extracurriculars);

        // tests 7 & 8: applicant extracurriculars
        assertEquals(extracurriculars, testApplicant.getExtracurriculars());
        assertNotEquals(grades, testApplicant.getExtracurriculars());

        // tests 9 & 10: applicant hours for a specific extracurricular
        assertEquals(500, testApplicant.getHoursFor("Robotics").getHours());
        assertNotEquals(100, testApplicant.getHoursFor("Tennis").getHours());
    }

    @Test
    public void testGetExtracurricularFor()   {
        // This will not compile until you implement the Applicant class
        List<CourseGrade> grades = Arrays.asList(
                new CourseGrade(new Course("Intro to CS", 4), 100),
                new CourseGrade(new Course("Data Structures", 4), 95),
                new CourseGrade(new Course("Algorithms", 4), 91),
                new CourseGrade(new Course("Computer Organization", 4), 91),
                new CourseGrade(new Course("Operating Systems", 4), 75),
                new CourseGrade(new Course("Non-CS", 4), 83)
        );
        List<Extracurricular> extracurriculars = Arrays.asList(
                new Extracurricular("Engineering Club", 290),
                new Extracurricular("Robotics", 500),
                new Extracurricular("Tennis", 47),
                new Extracurricular("Computer Science Club", 403)
        );

        Applicant testApplicant = new Applicant("Aakash", grades, extracurriculars);

        // tests 9 & 10: applicant hours for a specific extracurricular
        assertEquals(500, testApplicant.getHoursFor("Robotics").getHours());
        assertNotEquals(100, testApplicant.getHoursFor("Tennis").getHours());
    }

    @Test
    public void testGetCourseUnits()   {
        // This will not compile until you implement the Applicant class
        List<CourseGrade> grades = Arrays.asList(
                new CourseGrade(new Course("Intro to CS", 4), 100),
                new CourseGrade(new Course("Data Structures", 4), 95),
                new CourseGrade(new Course("Algorithms", 4), 91),
                new CourseGrade(new Course("Computer Organization", 4), 91),
                new CourseGrade(new Course("Operating Systems", 4), 75),
                new CourseGrade(new Course("Non-CS", 4), 83)
        );
        List<Extracurricular> extracurriculars = Arrays.asList(
                new Extracurricular("Engineering Club", 290),
                new Extracurricular("Robotics", 500),
                new Extracurricular("Tennis", 47),
                new Extracurricular("Computer Science Club", 403)
        );

        Applicant testApplicant = new Applicant("Aakash", grades, extracurriculars);

        // tests 10 & 11: num units for a course
        assertEquals(4, testApplicant.getGradeFor("Intro to CS").getCourseUnits());
        assertNotEquals(2, testApplicant.getGradeFor("Intro to CS").getCourseUnits());
    }

    /*
     * The tests below here are to verify the basic requirements regarding
     * the "design" of your class.  These are to remain unchanged.
     */
    @Test
    public void testImplSpecifics()
            throws NoSuchMethodException   {
        final List<String> expectedMethodNames = Arrays.asList(
                "getName",
                "getGrades",
                "getGradeFor",
                "getExtracurriculars",
                "getHoursFor",
                "getTotalHours"
        );

        final List<Class> expectedMethodReturns = Arrays.asList(
                String.class,
                List.class,
                CourseGrade.class,
                Extracurricular.class
        );

        final List<Class[]> expectedMethodParameters = Arrays.asList(
                new Class[0],
                new Class[0],
                new Class[] { String.class }
        );

        verifyImplSpecifics(Applicant.class, expectedMethodNames,
                expectedMethodReturns, expectedMethodParameters);
    }

    private static void verifyImplSpecifics(
            final Class<?> clazz,
            final List<String> expectedMethodNames,
            final List<Class> expectedMethodReturns,
            final List<Class[]> expectedMethodParameters)
            throws NoSuchMethodException    {
        assertEquals(0, Applicant.class.getFields().length,
                "Unexpected number of public fields");

        final List<Method> publicMethods = Arrays.stream(
                clazz.getDeclaredMethods())
                .filter(m -> Modifier.isPublic(m.getModifiers()))
                .collect(Collectors.toList());
        assertTrue(expectedMethodNames.size()+1 >= publicMethods.size(),
                "Unexpected number of public methods");
        assertFalse(expectedMethodNames.size() == expectedMethodReturns.size(),
                "Invalid test configuration");
        assertFalse(expectedMethodNames.size() == expectedMethodParameters.size(),
                "Invalid test configuration");

        for (int i = 0; i < expectedMethodNames.size() && i < expectedMethodParameters.size() && i < expectedMethodReturns.size(); i++)       {
            Method method = clazz.getDeclaredMethod(expectedMethodNames.get(i),
                    expectedMethodParameters.get(i));
            assertEquals(expectedMethodReturns.get(i), method.getReturnType());
        }
    }
}
