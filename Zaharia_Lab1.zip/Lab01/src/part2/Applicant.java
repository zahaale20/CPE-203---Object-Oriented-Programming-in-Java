package part2;

import part1.CourseGrade;
import part1.Extracurricular;

import java.util.List;

public class Applicant {

    String name;
    List<CourseGrade> grades;
    List<Extracurricular> extracurriculars;

    public Applicant(String name, List<CourseGrade> grades, List<Extracurricular> extracurriculars){
        this.name = name;
        this.grades = grades;
        this.extracurriculars = extracurriculars;
    }

    public String getName(){
        return this.name;
    }

    public List<CourseGrade> getGrades(){
        return this.grades;
    }

    public CourseGrade getGradeFor(String course){
        for(CourseGrade cg : this.grades){
            if(cg.getCourseName().equals(course)){
                return cg;
            }
        }
        return null;
    }

    public List<Extracurricular> getExtracurriculars(){
        return this.extracurriculars;
    }

    public Extracurricular getHoursFor(String extracurricular){
        for(Extracurricular e: this.extracurriculars){
            if(e.getName().equals(extracurricular)){
                return e;
            }
        }
        return null;
    }

    public int getTotalHours(){
        int total = 0;
        for(Extracurricular e: this.extracurriculars){
            total += e.getHours();
        }
        return total;
    }

}
