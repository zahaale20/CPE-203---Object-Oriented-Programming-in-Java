package part1;

import org.junit.jupiter.api.Test;
import part2.Applicant;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class TestCases {
   private final static double DELTA = 0.0001;

   ////////////////////////////////////////////////////////////
   //                      SimpleIf Tests                    //
   ////////////////////////////////////////////////////////////

   @Test
   public void testAnalyzeApplicant1()    {
      assertTrue(part1.SimpleIf.analyzeApplicant(89, 85));
   }

   @Test
   public void testAnalyzeApplicant2()    {
      assertFalse(part1.SimpleIf.analyzeApplicant(15, 90));
   }

   @Test
   public void testAnalyzeApplicant3()    {
      assertTrue(part1.SimpleIf.analyzeApplicant(100, 90));
   }

   @Test
   public void testAnalyzeApplicant4()    {
      List<CourseGrade> grades = Arrays.asList(
              new CourseGrade(new Course("Intro to CS", 4), 100),
              new CourseGrade(new Course("Data Structures", 4), 95),
              new CourseGrade(new Course("Algorithms", 4), 91),
              new CourseGrade(new Course("Computer Organization", 4), 91),
              new CourseGrade(new Course("Operating Systems", 4), 75),
              new CourseGrade(new Course("Non-CS", 4), 83)
      );
      List<Extracurricular> extracurriculars = Arrays.asList(
              new Extracurricular("Engineering Club", 290),
              new Extracurricular("Robotics", 500),
              new Extracurricular("Tennis", 47),
              new Extracurricular("Computer Science Club", 403)
      );
      Applicant applicant = new Applicant("Alex", grades, extracurriculars);
      assertTrue(part1.SimpleIf.analyzeApplicant2(applicant, 80, 1000));
   }

   @Test
   public void testAnalyzeApplicant5()    {
      List<CourseGrade> grades = Arrays.asList(
              new CourseGrade(new Course("Intro to CS", 4), 100),
              new CourseGrade(new Course("Data Structures", 4), 95),
              new CourseGrade(new Course("Algorithms", 4), 91),
              new CourseGrade(new Course("Computer Organization", 4), 91),
              new CourseGrade(new Course("Operating Systems", 4), 75),
              new CourseGrade(new Course("Non-CS", 4), 83)
      );
      List<Extracurricular> extracurriculars = Arrays.asList(
              new Extracurricular("Engineering Club", 50),
              new Extracurricular("Robotics", 10),
              new Extracurricular("Tennis", 40),
              new Extracurricular("Computer Science Club", 3)
      );
      Applicant applicant = new Applicant("Jason", grades, extracurriculars);
      assertFalse(part1.SimpleIf.analyzeApplicant2(applicant, 80, 1000));
   }

   @Test
   public void testAnalyzeApplicant6()    {
      List<CourseGrade> grades = Arrays.asList(
              new CourseGrade(new Course("Intro to CS", 4), 10),
              new CourseGrade(new Course("Data Structures", 4), 25),
              new CourseGrade(new Course("Algorithms", 4), 11),
              new CourseGrade(new Course("Computer Organization", 4), 31),
              new CourseGrade(new Course("Operating Systems", 4), 15),
              new CourseGrade(new Course("Non-CS", 4), 53)
      );
      List<Extracurricular> extracurriculars = Arrays.asList(
              new Extracurricular("Engineering Club", 500),
              new Extracurricular("Robotics", 100),
              new Extracurricular("Tennis", 4000),
              new Extracurricular("Computer Science Club", 3)
      );
      Applicant applicant = new Applicant("Ian", grades, extracurriculars);
      assertFalse(part1.SimpleIf.analyzeApplicant2(applicant, 80, 1000));
   }

   @Test
   public void testMaxAverage1() {
      assertEquals(part1.SimpleIf.maxAverage(89.5, 91.2), 91.2, DELTA);
   }

   @Test
   public void testMaxAverage2() {
      assertEquals(part1.SimpleIf.maxAverage(60, 89), 89, DELTA);
   }

   @Test
   public void testMaxAverage3() {
      assertEquals(part1.SimpleIf.maxAverage(101, 100), 101, DELTA);
   }

   ////////////////////////////////////////////////////////////
   //                    SimpleLoop Tests                    //
   ////////////////////////////////////////////////////////////

   @Test
   public void testSimpleLoop1()    {
      assertEquals(7, part1.SimpleLoop.sum(3, 4));
   }

   @Test
   public void testSimpleLoop2()    {
      assertEquals(7, part1.SimpleLoop.sum(-2, 4));
   }

   @Test
   public void testSimpleLoop3()    {
      assertEquals(6, part1.SimpleLoop.sum(0, 3));
   }

   ////////////////////////////////////////////////////////////
   //                    SimpleArray Tests                   //
   ////////////////////////////////////////////////////////////

   @Test
   public void testSimpleArray1()    {
      /* What is that parameter?  They are newly allocated arrays
         with initial values. */
      assertArrayEquals(
         new boolean[] {false, false, true, true, false, false},
         part1.SimpleArray.applicantAcceptable(new int[] {80, 85, 89, 92, 76, 81}, 85)
      );
   }

   @Test
   public void testSimpleArray2()    {
      assertArrayEquals(
         new boolean[] {false, false},
         part1.SimpleArray.applicantAcceptable(new int[] {80, 83}, 92));
   }

   @Test
   public void testSimpleArray3()   {
      assertArrayEquals(
              new boolean[] {true, true},
              part1.SimpleArray.applicantAcceptable(new int[] {70, 83}, 69));
   }

   ////////////////////////////////////////////////////////////
   //                    SimpleList Tests                    //
   ////////////////////////////////////////////////////////////

   @Test
   public void testSimpleList1()   {
      List<Integer> input =
         new LinkedList<Integer>(Arrays.asList(80, 85, 89, 92, 76, 81));
      List<Boolean> expected =
         new ArrayList<Boolean>(Arrays.asList(false, false, true, true, false, false));

      assertEquals(expected, SimpleList.applicantAcceptable(input, 85));
   }

   @Test
   public void testSimpleList2()   {
      List<Integer> input =
              new LinkedList<Integer>(Arrays.asList(79, 84, 90, 93, 77, 100));
      List<Boolean> expected =
              new ArrayList<Boolean>(Arrays.asList(false, false, true, true, false, true));

      assertEquals(expected, SimpleList.applicantAcceptable(input, 85));
   }

   ////////////////////////////////////////////////////////////
   //                    BetterLoop Tests                    //
   ////////////////////////////////////////////////////////////

   @Test
   public void testFourOver85_1()   {
      assertTrue(BetterLoop.atLeastFourOver85(new int[] {89, 93, 100, 69, 99, 100}));
   }

   @Test
   public void testFourOver85_2()   { assertFalse(BetterLoop.atLeastFourOver85(new int[] {16, 27, 50, 32, 43, 50}));
   }

   @Test
   public void testFourOver85_3()   {
      assertFalse(BetterLoop.atLeastFourOver85(new int[] {85, 85, 90, 83, 88, 90}));
   }

   ////////////////////////////////////////////////////////////
   //                    ExampleMap Tests                    //
   ////////////////////////////////////////////////////////////

   @Test
   public void testExampleMap1()   {
      Map<String, List<part1.CourseGrade>> courseListsByStudent = new HashMap<>();
      courseListsByStudent.put("Mary",
         Arrays.asList(
            new part1.CourseGrade(new Course("CPE 123", 4), 89),
            new part1.CourseGrade(new Course("CPE 101", 4), 90),
            new part1.CourseGrade(new Course("CPE 202", 4), 99),
            new part1.CourseGrade(new Course("CPE 203", 4), 100),
            new part1.CourseGrade(new Course("CPE 225", 4), 89)));
      courseListsByStudent.put("Sam",
         Arrays.asList(
            new part1.CourseGrade(new Course("CPE 101", 4), 86),
            new part1.CourseGrade(new Course("CPE 202", 4), 80),
            new part1.CourseGrade(new Course("CPE 203", 4), 76),
            new part1.CourseGrade(new Course("CPE 225", 4), 80)));
      courseListsByStudent.put("Sara",
         Arrays.asList(
            new part1.CourseGrade(new Course("CPE 123", 4), 99),
            new part1.CourseGrade(new Course("CPE 203", 4), 91),
            new part1.CourseGrade(new Course("CPE 471", 4), 86),
            new part1.CourseGrade(new Course("CPE 473", 4), 90),
            new part1.CourseGrade(new Course("CPE 476", 4), 99),
            new part1.CourseGrade(new Course("CPE 572", 4), 100)));

      List<String> expected = Arrays.asList("Mary", "Sara");

      /*
       * Why compare HashSets here?  Just so that the order of the
       * elements in the list is not important for this test.
       */
      assertEquals(new HashSet<>(expected),
         new HashSet<>(ExampleMap.highScoringStudents(
            courseListsByStudent, 85)));
   }

   @Test
   public void testExampleMap2()    {
      /* TO DO: Write another valid test case. */
      Map<String, List<part1.CourseGrade>> courseListsByStudent = new HashMap<>();
      courseListsByStudent.put("Enrique",
              Arrays.asList(
                      new part1.CourseGrade(new Course("MATH 123", 4), 90),
                      new part1.CourseGrade(new Course("MATH 101", 4), 91),
                      new part1.CourseGrade(new Course("MATH 202", 4), 100),
                      new part1.CourseGrade(new Course("MATH 203", 4), 101),
                      new part1.CourseGrade(new Course("MATH 225", 4), 90)));
      courseListsByStudent.put("Charles",
              Arrays.asList(
                      new part1.CourseGrade(new Course("MATH 101", 4), 87),
                      new part1.CourseGrade(new Course("MATH 202", 4), 81),
                      new part1.CourseGrade(new Course("MATH 203", 4), 77),
                      new part1.CourseGrade(new Course("MATH 225", 4), 81)));
      courseListsByStudent.put("Gregory",
              Arrays.asList(
                      new part1.CourseGrade(new Course("MATH 123", 4), 100),
                      new part1.CourseGrade(new Course("MATH 203", 4), 92),
                      new part1.CourseGrade(new Course("MATH 471", 4), 87),
                      new part1.CourseGrade(new Course("MATH 473", 4), 91),
                      new part1.CourseGrade(new Course("MATH 476", 4), 100),
                      new part1.CourseGrade(new Course("MATH 572", 4), 101)));

      List<String> expected = Arrays.asList("Enrique", "Gregory");

      /*
       * Why compare HashSets here?  Just so that the order of the
       * elements in the list is not important for this test.
       */
      assertEquals(new HashSet<>(expected),
              new HashSet<>(ExampleMap.highScoringStudents(
                      courseListsByStudent, 85)));
   }
}
