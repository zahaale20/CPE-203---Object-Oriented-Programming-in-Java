package part1;

public class Extracurricular {
    private String name;
    private int hours;

    public Extracurricular(String name, int hours){
        this.name = name;
        this.hours = hours;
    }

    public String getName(){
        return this.name;
    }

    public int getHours(){
        return this.hours;
    }
}
