import java.util.*;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class AStarPathingStrategy implements PathingStrategy {

    public List<Point> computePath(Point start, Point end,
                                   Predicate<Point> canPassThrough,
                                   BiPredicate<Point, Point> withinReach,
                                   Function<Point, Stream<Point>> potentialNeighbors) {

        List<Point> final_path = new ArrayList<>();
        Map<Point, AStarNode> closed_map = new HashMap<Point, AStarNode>();
        Map<Point, AStarNode> open_map = new HashMap<Point, AStarNode>();

        Queue<AStarNode> open_queue = new PriorityQueue<AStarNode>(Comparator.comparingInt(AStarNode::getFCost));
        AStarNode startNode = new AStarNode(calculateHeuristic(start, end), 0,
                calculateHeuristic(start, end), start, null);
        open_queue.add(startNode);
        AStarNode current_node = null;

        while (!open_queue.isEmpty()) {
            current_node = open_queue.remove();
            if (withinReach.test(current_node.getPosition(), end)) {
                return computedPath(final_path, current_node);
            }

            List<Point> neighbors_points = potentialNeighbors.apply(current_node.getPosition())
                    .filter(canPassThrough)
                    .filter(p -> !p.equals(start) && !p.equals(end)).collect(Collectors.toList());

            for (Point neighbor_point : neighbors_points) {
                if (!closed_map.containsKey(neighbor_point)) {

                    int temp_gCost = current_node.getGCost() + 1;
                    if (open_map.containsKey(neighbor_point)) {
                        if (temp_gCost < open_map.get(neighbor_point).getGCost()) {
                            AStarNode replacement_node = new AStarNode(calculateHeuristic(neighbor_point, end), temp_gCost,
                                    calculateHeuristic(neighbor_point, end) + temp_gCost, neighbor_point, current_node);
                            open_queue.add(replacement_node);
                            open_queue.remove(open_map.get(neighbor_point));
                            open_map.replace(neighbor_point, replacement_node);
                        }
                    } else {
                        AStarNode neighbor_node = new AStarNode(calculateHeuristic(neighbor_point, end), current_node.getGCost() + 1,
                                current_node.getGCost() + 1 + calculateHeuristic(neighbor_point, end), neighbor_point, current_node);
                        open_queue.add(neighbor_node);
                        open_map.put(neighbor_point, neighbor_node);
                    }

                }
                closed_map.put(current_node.getPosition(), current_node);
            }
        }
        return final_path;
    }


    public List<Point> computedPath(List<Point> compPath, AStarNode winner) {
        compPath.add(winner.getPosition());
        if (winner.getPrevious() == null) {
            Collections.reverse(compPath);
            return compPath;
        }
        return computedPath(compPath, winner.getPrevious());

    }

    public int calculateHeuristic(Point current, Point goal) {
        return current.distanceSquared(goal);
    }
}
