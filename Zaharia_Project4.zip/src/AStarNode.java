class AStarNode {
    private int hCost;
    private int gCost;
    private final int fCost;
    private Point position;
    private final AStarNode previous;

    public AStarNode(int hCost, int gCost, int fCost, Point position, AStarNode previous) {
        this.hCost = hCost;
        this.gCost = gCost;
        this.fCost = fCost;
        this.position = position;
        this.previous = previous;
    }

    public int getHCost() { return hCost; }

    public int getGCost() { return gCost; }

    public int getFCost() { return fCost; }

    public Point getPosition() { return position; }

    public AStarNode getPrevious() { return previous; }
}