import java.util.Comparator;

final class EventComparator implements Comparator<Event> {

    public int compare(Event e1, Event e2) {
        return (int) (e1.time - e2.time);
    }

}
