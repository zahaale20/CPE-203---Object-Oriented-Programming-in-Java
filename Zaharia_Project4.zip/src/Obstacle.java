import processing.core.PImage;
import java.util.List;


public class Obstacle extends Entity {

    public Obstacle(String id, List<PImage> images, Point position)
    {
        super(id, images, position);
    }

}