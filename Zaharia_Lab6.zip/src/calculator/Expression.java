package calculator;

public interface Expression
        extends Operation {
}
