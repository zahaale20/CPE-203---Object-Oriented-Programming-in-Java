package calculator;
class ScannerException extends Exception {
}

