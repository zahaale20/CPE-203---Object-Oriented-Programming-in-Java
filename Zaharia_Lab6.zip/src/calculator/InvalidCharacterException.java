package calculator;
class InvalidCharacterException extends ScannerException {

}
