package calculator;

class NegationExpression implements Expression {
    private final Expression op;

    public NegationExpression(final Expression op) {
        this.op = op;
    }

    public String toString() {
        return "-" + op;
    }

    public double evaluate(final Bindings bindings) {
        return - op.evaluate(bindings);
    }
}
