package equality;

import org.junit.Test;

import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class TestCases {
    private static final List<CourseSection> lst = Arrays.asList(
            new CourseSection("CSC", "203", 35, LocalTime.of(9, 40), LocalTime.of(11, 0)),
            new CourseSection("CSC", "203", 35, LocalTime.of(9, 40), LocalTime.of(11, 0))
    );

    @Test
    public void testExercise1() {
        final CourseSection one = new CourseSection("CSC", "203", 35,
                LocalTime.of(9, 40), LocalTime.of(11, 0));
        final CourseSection two = new CourseSection("CSC", "203", 35,
                LocalTime.of(9, 40), LocalTime.of(11, 0));

        assertEquals(one, two);
        assertEquals(two, one);
    }

    @Test
    public void testExercise2() {
        final CourseSection one = new CourseSection("CSC", "203", 35,
                LocalTime.of(9, 10), LocalTime.of(10, 0));
        final CourseSection two = new CourseSection("CSC", "203", 35,
                LocalTime.of(1, 10), null);

        assertNotEquals(one, two);
        assertNotEquals(two, one);
    }

    @Test
    public void testExercise3() {
        final CourseSection one = new CourseSection("CSC", "203", 35,
                LocalTime.of(9, 40), LocalTime.of(11, 0));
        final CourseSection two = new CourseSection("CSC", "203", 35,
                LocalTime.of(9, 40), LocalTime.of(11, 0));
        assertEquals(one.hashCode(), two.hashCode());
    }

    @Test
    public void testExercise4() {
        final CourseSection one = new CourseSection("CSC", "203", 35,
                LocalTime.of(9, 10), LocalTime.of(10, 0));
        final CourseSection two = new CourseSection("CSC", "203", 34,
                LocalTime.of(9, 10), LocalTime.of(10, 0));

        assertNotEquals(one.hashCode(), two.hashCode());
    }

    @Test
    public void testExercise5() {
        final Student s1 = new Student("Alvin", "Kamara", 35, lst);
        final Student s2 = new Student("Alvin", "Kamara", 35, lst);
        assertEquals(s1, s2);
    }

    @Test
    public void testExercise6() {
        final Student s1 = new Student("Alvin", "Kamara", 35, lst);
        final Student s2 = new Student("Alvin", "Kamara", 42, lst);
        assertNotEquals(s1, s2);
    }

    @Test
    public void testExercise7() {
        final Student s1 = new Student("Alvin", "Kamara", 35, lst);
        final Student s2 = new Student("Derrick", "Henry", 42, lst);
        assertNotEquals(s1, s2);
    }

    @Test
    public void testExercise8() {
        final Student s1 = new Student("Alvin", "Kamara", 35, lst);
        final Student s2 = new Student("Derrick", "Henry", 42, lst);
        assertNotEquals(s1.hashCode(), s2.hashCode());
    }

    @Test
    public void testExercise9() {
       final Student s1 = new Student("Alvin", "Kamara", 35, lst);
       final Student s2 = new Student("Alvin", "Kamara", 35, lst);
        assertEquals(s1.hashCode(), s2.hashCode());
    }

    @Test
    public void testExercise10() {
       final Student s1 = new Student("Alvin", "Kamara", 35, lst);
       final Student s2 = new Student("Alvin", "Kamara", 19, lst);
        assertNotEquals(s1.hashCode(), s2.hashCode());
    }
}
