package equality;

import java.time.LocalTime;

class CourseSection {
    private final String prefix;
    private final String number;
    private final int enrollment;
    private final LocalTime startTime;
    private final LocalTime endTime;

    public CourseSection(final String prefix, final String number,
                         final int enrollment, final LocalTime startTime, final LocalTime endTime) {
        this.prefix = prefix;
        this.number = number;
        this.enrollment = enrollment;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public int hashCode() {
        return 31 * (prefix.hashCode() + number.hashCode() + ((Integer) enrollment).hashCode()
                    + startTime.hashCode() + endTime.hashCode());
    }

    public boolean equals(Object o) {
        if (o != null) {
            if (getClass() == o.getClass()) {

                boolean prefix_tf, number_tf, enrollment_tf, startTime_tf, endTime_tf;

                if (prefix == null) { prefix_tf = ((CourseSection) o).prefix == null; }
                else { prefix_tf = prefix.equals(((CourseSection) o).prefix); }

                if (number == null) { number_tf = ((CourseSection) o).number == null; }
                else { number_tf = number.equals(((CourseSection) o).number); }

                if (startTime == null) { startTime_tf = ((CourseSection) o).startTime == null; }
                else { startTime_tf = startTime.equals(((CourseSection) o).startTime); }

                if (endTime == null) { endTime_tf = ((CourseSection) o).endTime == null; }
                else { endTime_tf = endTime.equals(((CourseSection) o).endTime); }

                enrollment_tf = enrollment == ((CourseSection) o).enrollment;

                return prefix_tf && number_tf && enrollment_tf && startTime_tf && endTime_tf;
            }
        }
        return false;
    }
}
