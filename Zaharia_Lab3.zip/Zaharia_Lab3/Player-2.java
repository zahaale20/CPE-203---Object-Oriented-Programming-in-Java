import java.util.*;

class Player {
	private PlayerKind kind;
	private float money;
	private ArrayList<Float> moneyOverTime;
    Random random = new Random();
	private int red, green, blue;
	private ArrayList<Integer> lottoNums = new ArrayList<>();

	//constructor
	public Player(PlayerKind pK, float startFunds) {
		kind = pK;
		money = startFunds;
		moneyOverTime = new ArrayList<Float>();
		moneyOverTime.add(startFunds);
		red = random.nextInt(100);
		green = random.nextInt(100);
		blue = random.nextInt(100);

		//overall blue tint to POORLY_PAID	
		if (kind == PlayerKind.WELL_PAID) {
			red += 100;
		} else {
			blue += 100;
		}
		playRandom();
	}

	private void playRandom() {
		while(lottoNums.size() <= 5){
			int lottoNum = random.nextInt(42);
			if(!lottoNums.contains(lottoNum)){
				lottoNums.add(lottoNum);
			}
		}
	}

	public int getR() { return red; }
	public int getG() { return green; }
	public int getB() { return blue; }
	public ArrayList<Integer> getLottoNums(){ return lottoNums; }
	public void addMoney(float m){
		money += m;
	}
	public float getMoney() { return money; }
	public PlayerKind getKind() { return kind; }
	public ArrayList<Float> getFunds() { return moneyOverTime; }
	public void updateMoneyEachYear() {
		moneyOverTime.add(money);
	}

}
