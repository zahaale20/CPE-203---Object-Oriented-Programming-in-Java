import java.util.ArrayList;
import java.util.Random;

public class Game {
    private ArrayList<Player> players;
    private ArrayList<Integer> winningNums = new ArrayList<>();
    private Random rand = new Random();

    public Game(ArrayList<Player> p){
        players = p;
        winningLotNumber();
        for(Player player : players){
            player.addMoney(calculateWinnings(player));
        }
    }

    private void winningLotNumber(){
        int lottoNum = rand.nextInt(42);
        if(winningNums.size() < 6 && !winningNums.contains(lottoNum)){
            winningNums.add(lottoNum);
            winningLotNumber();
        } else if (winningNums.size() < 6){
            winningLotNumber();
        }
    }

    private int compareNums(Player player){
        int same = 0;
        for(int num : player.getLottoNums()){
            if(winningNums.contains(num)){
                same++;
            }
        }
        return same;
    }

    private float calculateWinnings(Player player){
        int matches = compareNums(player);
        if(matches == 2){
            return 1.00f;
        } else if (matches == 3){
            return 10.86f;
        } else if (matches == 4){
            return 197.86f;
        } else if (matches == 5){
            return 212534.83f;
        }
        distributeScholarship();
        return -1.00f;
    }

    private void distributeScholarship() {
        int num = rand.nextInt(99) + 1;
        int rand_num;
        if(num <= 30){
            rand_num = rand.nextInt((int) (players.size() * 0.6));
        } else {
            rand_num = (int) (rand.nextInt((int) (players.size() * 0.4)) + players.size() * 0.6);
        }
        players.get(rand_num).addMoney(1.0f);
        //System.out.println(num + ": " + rand_num + " of " + players.size());
    }
}
