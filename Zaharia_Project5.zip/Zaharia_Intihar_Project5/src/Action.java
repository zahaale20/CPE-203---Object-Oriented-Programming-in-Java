/*
Action: ideally what our various entities might do in our virutal world
 */

public interface Action {
   public void executeAction(EventScheduler scheduler);
}
