import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class SickOcto extends Octo {
    public int life;

    public SickOcto(String id, Point position, List<PImage> images, int actionPeriod, int animationPeriod, int rLimit, int rCount, int r, int life) {
        super(id, position, images, actionPeriod, animationPeriod, rLimit, rCount, r);
        this.life = life;
    }

    public void executeActivity(ImageStore imageStore, EventScheduler scheduler, WorldModel worldModel) {
        this.life++;
        if (plague(worldModel, scheduler, imageStore)) {

        } else {

            Optional<Entity> fullTarget = worldModel.findNearest(position,
                    OctoNotFull.class);

            if (fullTarget.isPresent() &&
                    this.moveToSick(worldModel, fullTarget.get(), scheduler)) {


                infect(worldModel, scheduler, imageStore, fullTarget.get());
            }
            scheduler.scheduleEvent(this,
                    new Activityy(this, worldModel, imageStore),
                    600);

        }

    }

    public boolean moveToSick(WorldModel worldModel,
                              Entity target, EventScheduler scheduler) {

        if (getPosition().adjacent(target.getPosition())) {
            return true;
        } else {
            Point nextPos = nextPosition(worldModel, target.getPosition());

            if (!getPosition().equals(nextPos)) {
                Optional<Entity> occupant = worldModel.getOccupant(nextPos);
                if (occupant.isPresent()) {
                    scheduler.unscheduleAllEvents(occupant.get());
                }

                worldModel.moveEntity(this, nextPos);
            }
            return false;
        }
    }

    public void infect(WorldModel world,
                       EventScheduler scheduler, ImageStore imageStore, Entity target) {

        Entity octo = new SickOcto(this.id,
                target.position, this.images, this.actionPeriod, this.animationPeriod,
                this.resourceLimit, 0, 0, 0);

        world.removeEntity(target);
        scheduler.unscheduleAllEvents(target);

        world.addEntity(octo);
        ((Animated) octo).scheduleActions(scheduler, world, imageStore);
    }

    public boolean plague(WorldModel world,
                          EventScheduler scheduler, ImageStore imageStore) {
        if (this.life >= 30) {
            world.removeEntity(this);
            scheduler.unscheduleAllEvents(this);

            return true;
        }

        return false;
    }
}
