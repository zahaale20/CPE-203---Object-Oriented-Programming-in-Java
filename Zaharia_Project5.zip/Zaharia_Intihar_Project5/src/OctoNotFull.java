import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class OctoNotFull extends Octo {


    public OctoNotFull(String id, Point position, List<PImage> images, int actionPeriod, int animationPeriod, int r, int resourceLimit, int resourceCount) {
        super(id, position, images, actionPeriod, animationPeriod, resourceLimit, resourceCount, r);
    }

    public static Entity createOctoNotFull(String id, int resourceLimit,
                                           Point position, int actionPeriod, int animationPeriod,
                                           List<PImage> images) {
        return new OctoNotFull(id, position, images, actionPeriod, animationPeriod, 0, 4, 0);
    }

    public boolean moveToNotFull(WorldModel worldModel,
                                 Entity target, EventScheduler scheduler) {
        if (getPosition().adjacent(target.getPosition())) {
            super.resourceCount++;
            worldModel.removeEntity(target);
            scheduler.unscheduleAllEvents(target);

            return true;
        } else {
            Point nextPos = nextPosition(worldModel, target.getPosition());

            if (!getPosition().equals(nextPos)) {
                Optional<Entity> occupant = worldModel.getOccupant(nextPos);
                if (occupant.isPresent()) {
                    scheduler.unscheduleAllEvents(occupant.get());
                }

                worldModel.moveEntity(this, nextPos);
            }
            return false;
        }
    }

    public boolean transformNotFull(WorldModel world,
                                    EventScheduler scheduler, ImageStore imageStore) {
        if (this.resourceCount >= this.resourceLimit) {
            Entity octo = OctoFull.createOctoFull(this.id, this.resourceLimit,
                    this.position, this.actionPeriod, this.animationPeriod,
                    this.images);

            world.removeEntity(this);
            scheduler.unscheduleAllEvents(this);

            world.addEntity(octo);
            ((Animated) octo).scheduleActions(scheduler, world, imageStore);

            return true;
        }

        return false;
    }


    public void executeActivity(ImageStore imageStore, EventScheduler scheduler, WorldModel worldModel) {
        Optional<Entity> notFullTarget = worldModel.findNearest(position,
                Fish.class);

        if (!notFullTarget.isPresent() ||
                !this.moveToNotFull(worldModel, notFullTarget.get(), scheduler) ||
                !transformNotFull(worldModel, scheduler, imageStore)) {
            scheduler.scheduleEvent(this,
                    new Activityy(this, worldModel, imageStore),
                    actionPeriod);
        }
    }


}
