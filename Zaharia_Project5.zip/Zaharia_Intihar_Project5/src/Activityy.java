public class Activityy implements Action {
    private final Active entity;

    private final WorldModel world;
    private final ImageStore imageStore;

    public Activityy(Active e, WorldModel w, ImageStore i) {
        this.entity = e;
        this.world = w;
        this.imageStore = i;
    }

    public void executeAction(EventScheduler scheduler) {
        this.entity.executeActivity(this.imageStore, scheduler, this.world);
    }

}

