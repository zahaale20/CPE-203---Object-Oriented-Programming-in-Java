import processing.core.PImage;

import java.util.List;

public abstract class Octo extends PathingEntity {
    protected int resourceLimit;
    protected int resourceCount;

    public Octo(String id, Point position, List<PImage> images, int actionPeriod, int animationPeriod, int rLimit, int rCount, int r) {
        super(id, position, images, actionPeriod, animationPeriod, r);
        this.resourceLimit = rLimit;
        this.resourceCount = rCount;
    }

    public int getResource() {
        return resourceCount;
    }

    public void setResource(int r) {
        resourceCount = r;

    }
}
