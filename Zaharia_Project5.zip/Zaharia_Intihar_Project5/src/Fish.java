import processing.core.PImage;

import java.util.List;

public class Fish extends Active{

    private static final String CRAB_ID_SUFFIX = " -- crab";
    private static final int CRAB_PERIOD_SCALE = 4;
    private static final int CRAB_ANIMATION_MIN = 50;
    private static final int CRAB_ANIMATION_MAX = 150;


    public Fish(String id, Point position, List<PImage> images, int actionPeriod) {
        super(id, position, images, actionPeriod);
    }

    public void executeActivity(ImageStore imageStore, EventScheduler scheduler, WorldModel worldModel)
    {
        Point pos = position;  // store current position before removing

        worldModel.removeEntity(this);
        scheduler.unscheduleAllEvents(this);

        Entity crab = Crab.createCrab(id + CRAB_ID_SUFFIX, pos,
                actionPeriod / CRAB_PERIOD_SCALE,
                CRAB_ANIMATION_MIN +
                        Functions.rand.nextInt(CRAB_ANIMATION_MAX - CRAB_ANIMATION_MIN),
                imageStore.getImageList(Functions.CRAB_KEY));

        worldModel.addEntity(crab);
        ((Animated) crab).scheduleActions(scheduler, worldModel, imageStore);
    }
    public static Entity createFish(String id, Point position, int actionPeriod,
                                    List<PImage> images)
    {
        return new Fish(id, position, images, actionPeriod);
    }


}
