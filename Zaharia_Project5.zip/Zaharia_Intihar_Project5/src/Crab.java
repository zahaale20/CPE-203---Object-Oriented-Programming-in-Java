import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class Crab extends PathingEntity {


    public Crab(String id, Point position, List<PImage> images, int actionPeriod, int animationPeriod) {
        super(id, position, images, actionPeriod, animationPeriod, 0);
    }

    public static Entity createCrab(String id, Point position,
                                    int actionPeriod, int animationPeriod, List<PImage> images) {
        return new Crab(id, position, images, actionPeriod, animationPeriod);
    }

    public Point nextPosition(WorldModel world, Point destPos) {
        int horiz = Integer.signum(destPos.x - this.position.x);
        Point newPos = new Point(this.position.x + horiz,
                this.position.y);

        Optional<Entity> occupant = world.getOccupant(newPos);

        if (horiz == 0 ||
                (occupant.isPresent() && !(occupant.get() instanceof Fish))) {
            int vert = Integer.signum(destPos.y - this.position.y);
            newPos = new Point(this.position.x, this.position.y + vert);
            occupant = world.getOccupant(newPos);

            if (vert == 0 ||
                    (occupant.isPresent() && !(occupant.get() instanceof Fish))) {
                newPos = this.position;
            }
        }

        return newPos;
    }

    public void executeActivity(ImageStore imageStore, EventScheduler scheduler, WorldModel worldModel) {
        Optional<Entity> crabTarget = worldModel.findNearest(
                position, Seagrass.class);
        long nextPeriod = actionPeriod;

        if (crabTarget.isPresent()) {
            Point tgtPos = crabTarget.get().getPosition();

            if (worldModel.moveToCrab(this, crabTarget.get(), scheduler)) {
                Entity quake = Quake.createQuake(tgtPos,
                        imageStore.getImageList(Functions.QUAKE_KEY));

                worldModel.addEntity(quake);
                nextPeriod += actionPeriod;
                ((Animated) quake).scheduleActions(scheduler, worldModel, imageStore);
            }
        }

        scheduler.scheduleEvent(this,
                new Activityy(this, worldModel, imageStore),
                nextPeriod);
    }


}
