public class Animation implements Action{
    private int repeatCount;
    private Animated entity;
    public Animation(Animated e,int r){
        this.repeatCount = r;
        this.entity = e;
    }
    @Override
    public void executeAction(EventScheduler scheduler) {
        this.entity.nextImage();
        if (this.repeatCount != 1) {
            scheduler.scheduleEvent(this.entity,
                    new Animation(
                            this.entity, Math.max(this.repeatCount - 1, 0)),
                    this.entity.getAnimationPeriod());
        }
    }
}
