import processing.core.PImage;

import java.util.List;

public class Atlantis extends Animated {
    public Atlantis(String id, Point position, List<PImage> images, int actionPeriod, int animationPeriod, int r) {
        super(id, position, images, actionPeriod, animationPeriod, r);
    }

    public static Entity createAtlantis(String id, Point position,
                                        List<PImage> images) {
        return new Atlantis(id, position, images,
                0, 70, 7);
    }

    public void executeActivity(ImageStore imageStore, EventScheduler scheduler, WorldModel worldModel) {
        scheduler.unscheduleAllEvents(this);
        //worldModel.removeEntity(this);
    }


}
