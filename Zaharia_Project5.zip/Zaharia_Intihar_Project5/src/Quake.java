import processing.core.PImage;

import java.util.List;

public class Quake extends Animated {
    public static final String QUAKE_KEY = "quake";
    private static final String QUAKE_ID = "quake";
    private static final int QUAKE_ACTION_PERIOD = 1100;
    private static final int QUAKE_ANIMATION_PERIOD = 100;
    private static final int QUAKE_ANIMATION_REPEAT_COUNT = 10;

    public Quake(String id, Point position, List<PImage> images, int actionPeriod, int animationPeriod, int r) {
        super(id, position, images, actionPeriod, animationPeriod, r);
    }

    public static Entity createQuake(Point position, List<PImage> images) {
        return new Quake(QUAKE_ID, position, images, QUAKE_ACTION_PERIOD, QUAKE_ANIMATION_PERIOD, 10);
    }

    public void executeActivity(ImageStore imageStore, EventScheduler scheduler, WorldModel worldModel) {
        scheduler.unscheduleAllEvents(this);
        worldModel.removeEntity(this);
    }


}
