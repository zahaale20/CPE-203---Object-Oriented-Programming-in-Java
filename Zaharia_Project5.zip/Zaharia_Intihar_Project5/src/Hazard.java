import processing.core.PImage;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Hazard extends Animated {

    private static final String HAZARD_KEY = "hazard";
    private static final int HAZARD_PERIOD_SCALE = 4;
    private static final int HAZARD_ANIMATION_MIN = 50;
    private static final int HAZARD_ANIMATION_MAX = 150;

    private List<Point> oil;

    public Hazard(Point position, List<PImage> images, WorldModel world, ImageStore imageStore) {
        super(HAZARD_KEY, position, images, 100000, 100000, 0);
        createOil(world, imageStore);

    }

    private void createOil(WorldModel world, ImageStore imageStore) {
        oil = new ArrayList<>();
        oil.add(new Point(position.getX(), position.getY()));
        oil.add(new Point(position.getX() - 1, position.getY()));
        oil.add(new Point(position.getX() + 1, position.getY()));
        oil.add(new Point(position.getX(), position.getY() - 1));
        oil.add(new Point(position.getX(), position.getY() + 1));

        for (Point o : oil) {
            world.setBackground(o, new Background("oil", imageStore.getImageList("oil")));
        }
    }

    public void executeActivity(ImageStore imageStore, EventScheduler scheduler, WorldModel worldModel) {
        Optional<Entity> fullTarget = worldModel.findNearest(position,
                OctoNotFull.class);

        if (fullTarget.isPresent() &&
                this.moveToSick(worldModel, fullTarget.get(), scheduler)) {

            infect(worldModel, scheduler, imageStore, fullTarget.get());
        }
        scheduler.scheduleEvent(this,
                new Activityy(this, worldModel, imageStore),
                100);

    }


    public boolean moveToSick(WorldModel worldModel,
                              Entity target, EventScheduler scheduler) {

        return getPosition().adjacent(target.getPosition());
    }

    public void infect(WorldModel world, EventScheduler scheduler, ImageStore imageStore, Entity target) {

        Entity octo = new SickOcto("sickocto",
                target.position, imageStore.getImageList("sickocto"), 600, 100,
                10, 0, 0, 0);

        world.removeEntity(target);
        scheduler.unscheduleAllEvents(target);

        world.addEntity(octo);
        ((Animated) octo).scheduleActions(scheduler, world, imageStore);
    }


    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, new Activityy(this, world, imageStore), this.actionPeriod);
    }


}
