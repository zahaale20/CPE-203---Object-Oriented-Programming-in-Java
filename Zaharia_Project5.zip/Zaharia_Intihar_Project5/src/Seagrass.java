import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class Seagrass extends Active {


    private static final String FISH_ID_PREFIX = "fish -- ";
    private static final int FISH_CORRUPT_MIN = 20000;
    private static final int FISH_CORRUPT_MAX = 30000;

    public Seagrass(String id, Point position, List<PImage> images, int actionPeriod) {
        super(id, position, images, actionPeriod);
    }

    public static Entity createSgrass(String id, Point position, int actionPeriod,
                                      List<PImage> images) {
        return new Seagrass(id, position, images,
                actionPeriod);
    }

    public void executeActivity(ImageStore imageStore, EventScheduler scheduler, WorldModel worldModel) {
        Optional<Point> openPt = position.findOpenAround(worldModel);

        if (openPt.isPresent()) {
            Entity fish = Fish.createFish(FISH_ID_PREFIX + id, openPt.get(),
                    FISH_CORRUPT_MIN +
                            Functions.rand.nextInt(FISH_CORRUPT_MAX - FISH_CORRUPT_MIN),
                    imageStore.getImageList(Functions.FISH_KEY));
            worldModel.addEntity(fish);
            ((Active) fish).scheduleActions(scheduler, worldModel, imageStore);
        }

        scheduler.scheduleEvent(this,
                new Activityy(this, worldModel, imageStore),
                actionPeriod);
    }


}
