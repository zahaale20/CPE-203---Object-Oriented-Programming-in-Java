import processing.core.PImage;

import java.util.List;

public abstract class Animated extends Active {

    protected int animationPeriod;
    protected int animationCount;

    public void nextImage()
    {
        this.imageIndex = (this.imageIndex + 1) % this.images.size();
    }

    public int getAnimationPeriod()
    {
        return this.animationPeriod;
    }

    public void scheduleActions(EventScheduler eventScheduler, WorldModel world, ImageStore imageStore) {
        eventScheduler.scheduleEvent(this, new Activityy(this, world, imageStore), actionPeriod);
        eventScheduler.scheduleEvent(this, new Animation(this, this.animationCount), getAnimationPeriod());
    }

    public Animated(String id, Point position, List<PImage> images, int actionPeriod, int animationPeriod, int r) {
        super(id, position, images, actionPeriod);
        this.animationPeriod = animationPeriod;
        this.animationCount = r;
    }
}

