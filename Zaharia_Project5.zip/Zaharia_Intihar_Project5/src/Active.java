import processing.core.PImage;

import java.util.List;

public abstract class Active extends Entity{

    protected int actionPeriod;

    public void scheduleActions(EventScheduler eventScheduler, WorldModel world, ImageStore imageStore) {
        eventScheduler.scheduleEvent(this,
                new Activityy(this, world, imageStore),
                actionPeriod);
    }

    public Active(String id, Point position, List<PImage> images, int actionPeriod) {
        super(id, position, images);
        this.actionPeriod = actionPeriod;
    }

    public int getActionP(){
        return this.actionPeriod;
    }

    public abstract void executeActivity(ImageStore imageStore, EventScheduler scheduler, WorldModel worldModel);

}

