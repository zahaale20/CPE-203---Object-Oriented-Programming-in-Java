import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class OctoFull extends Octo {


    public OctoFull(String id, Point position, List<PImage> images, int actionPeriod, int animationPeriod, int r, int resourceLimit, int resourceCount) {
        super(id, position, images, actionPeriod, animationPeriod, resourceLimit, resourceCount, r);
    }

    public static Entity createOctoFull(String id, int resourceLimit,
                                        Point position, int actionPeriod, int animationPeriod,
                                        List<PImage> images) {
        return new OctoFull(id, position, images,
                actionPeriod, animationPeriod, 0, resourceLimit, resourceLimit);
    }

    public boolean moveToFull(WorldModel worldModel,
                              Entity target, EventScheduler scheduler) {
        if (getPosition().adjacent(target.getPosition())) {
            return true;
        } else {
            Point nextPos = nextPosition(worldModel, target.getPosition());

            if (!getPosition().equals(nextPos)) {
                Optional<Entity> occupant = worldModel.getOccupant(nextPos);
                if (occupant.isPresent()) {
                    scheduler.unscheduleAllEvents(occupant.get());
                }

                worldModel.moveEntity(this, nextPos);
            }
            return false;
        }
    }

    public void transformFull(WorldModel world,
                              EventScheduler scheduler, ImageStore imageStore) {
        Entity octo = OctoNotFull.createOctoNotFull(this.id, this.resourceLimit,
                this.position, this.actionPeriod, this.animationPeriod,
                this.images);

        world.removeEntity(this);
        scheduler.unscheduleAllEvents(this);

        world.addEntity(octo);
        ((Animated) octo).scheduleActions(scheduler, world, imageStore);
    }

    public void executeActivity(ImageStore imageStore, EventScheduler scheduler, WorldModel worldModel) {
        Optional<Entity> fullTarget = worldModel.findNearest(position,
                Atlantis.class);

        if (fullTarget.isPresent() &&
                this.moveToFull(worldModel, fullTarget.get(), scheduler)) {
            //at atlantis trigger animation
            ((Atlantis) fullTarget.get()).scheduleActions(scheduler, worldModel, imageStore);

            //transform to unfull
            transformFull(worldModel, scheduler, imageStore);
        } else {
            scheduler.scheduleEvent(this,
                    new Activityy(this, worldModel, imageStore),
                    actionPeriod);
        }
    }


}
