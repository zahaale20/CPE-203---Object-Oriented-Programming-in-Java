import processing.core.PImage;

import java.util.*;

/*
Functions - everything our virtual world is doing right now - is this a good design?
 */

final class Functions {
    public static final Random rand = new Random();

    public static final String OCTO_KEY = "octo";
    public static final String OBSTACLE_KEY = "obstacle";
    public static final String FISH_KEY = "fish";
    public static final int FISH_REACH = 1;
    public static final String ATLANTIS_KEY = "atlantis";
    public static final String SGRASS_KEY = "seaGrass";
    public static final String CRAB_KEY = "crab";
    public static final String QUAKE_KEY = "quake";
    private static final int OCTO_NUM_PROPERTIES = 7;
    private static final int OCTO_ID = 1;
    private static final int OCTO_COL = 2;
    private static final int OCTO_ROW = 3;
    private static final int OCTO_LIMIT = 4;
    private static final int OCTO_ACTION_PERIOD = 5;
    private static final int OCTO_ANIMATION_PERIOD = 6;
    private static final int OBSTACLE_NUM_PROPERTIES = 4;
    private static final int OBSTACLE_ID = 1;
    private static final int OBSTACLE_COL = 2;
    private static final int OBSTACLE_ROW = 3;
    private static final int FISH_NUM_PROPERTIES = 5;
    private static final int FISH_ID = 1;
    private static final int FISH_COL = 2;
    private static final int FISH_ROW = 3;
    private static final int FISH_ACTION_PERIOD = 4;
    private static final int ATLANTIS_NUM_PROPERTIES = 4;
    private static final int ATLANTIS_ID = 1;
    private static final int ATLANTIS_COL = 2;
    private static final int ATLANTIS_ROW = 3;
    private static final int ATLANTIS_ANIMATION_PERIOD = 70;
    private static final int ATLANTIS_ANIMATION_REPEAT_COUNT = 7;
    private static final int SGRASS_NUM_PROPERTIES = 5;
    private static final int SGRASS_ID = 1;
    private static final int SGRASS_COL = 2;
    private static final int SGRASS_ROW = 3;
    private static final int SGRASS_ACTION_PERIOD = 4;
    private static final String QUAKE_ID = "quake";
    private static final int QUAKE_ACTION_PERIOD = 1100;
    private static final int QUAKE_ANIMATION_PERIOD = 100;
    private static final int QUAKE_ANIMATION_REPEAT_COUNT = 10;


    private static final String BGND_KEY = "background";
    private static final int BGND_NUM_PROPERTIES = 4;
    private static final int BGND_ID = 1;
    private static final int BGND_COL = 2;
    private static final int BGND_ROW = 3;


    private static final int PROPERTY_KEY = 0;


    public static List<PImage> getImages(Map<String, List<PImage>> images,
                                         String key) {
        List<PImage> imgs = images.get(key);
        if (imgs == null) {
            imgs = new LinkedList<>();
            images.put(key, imgs);
        }
        return imgs;
    }


    public static void load(Scanner in, WorldModel world, ImageStore imageStore) {
        int lineNumber = 0;
        while (in.hasNextLine()) {
            try {
                if (!processLine(in.nextLine(), world, imageStore)) {
                    System.err.println(String.format("invalid entry on line %d",
                            lineNumber));
                }
            } catch (NumberFormatException e) {
                System.err.println(String.format("invalid entry on line %d",
                        lineNumber));
            } catch (IllegalArgumentException e) {
                System.err.println(String.format("issue on line %d: %s",
                        lineNumber, e.getMessage()));
            }
            lineNumber++;
        }
    }

    public static boolean processLine(String line, WorldModel world,
                                      ImageStore imageStore) {
        String[] properties = line.split("\\s");
        if (properties.length > 0) {
            switch (properties[PROPERTY_KEY]) {
                case BGND_KEY:
                    return Background.parseBackground(properties, world, imageStore);
                case OCTO_KEY:
                    return world.parseOcto(properties, imageStore);
                case OBSTACLE_KEY:
                    return world.parseObstacle(properties, imageStore);
                case FISH_KEY:
                    return world.parseFish(properties, imageStore);
                case ATLANTIS_KEY:
                    return world.parseAtlantis(properties, imageStore);
                case SGRASS_KEY:
                    return world.parseSgrass(properties, imageStore);
            }
        }

        return false;
    }


    public static int clamp(int value, int low, int high) {
        return Math.min(high, Math.max(value, low));
    }


}
