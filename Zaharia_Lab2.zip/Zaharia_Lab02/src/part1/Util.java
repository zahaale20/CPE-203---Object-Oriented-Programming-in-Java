package part1;

import java.util.Map;

public class Util {
    public static int getYearWithHighestEmissions(Country country){
        double highestEmission = 0;
        int year = 0;
        for(Map.Entry<Integer, Emission> entry: country.getEmissions().entrySet()){
            double totalEmission = entry.getValue().getCO2() + entry.getValue().getN2O() + entry.getValue().getCH4();
            if(totalEmission > highestEmission){
                highestEmission = totalEmission;
                year = entry.getKey();
            }
        }
        return year;
    }

    public static int getYearWithHighestEmissions(Sector sector){
        double highestEmission = 0;
        int year = 0;
        for(Map.Entry<Integer, Double> entry: sector.getEmissions().entrySet()){
            if(entry.getValue() > highestEmission){
                highestEmission = entry.getValue();
                year = entry.getKey();
            }
        }
        return year;
    }
}
