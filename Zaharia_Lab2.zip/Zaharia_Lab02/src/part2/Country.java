package part2;

import java.util.List;
import java.util.Map;


public class Country {
    private String name;
    private Map<Integer, Emission> emissions;
    private int highestEmissionYear;

    public Country(String name, Map<Integer, Emission> emissions){
        this.name = name;
        this.emissions = emissions;
        this.highestEmissionYear = getYearWithHighestEmissions();
    }

    public String getName(){
        return this.name;
    }

//    public void setName(String name){ this.name = name;}

    public Map<Integer, Emission> getEmissions(){
        return this.emissions;
    }

//    public void setEmissions(Map<Integer, Emission> emissions){ this.emissions = emissions};

    public int getYearWithHighestEmissions(){
        double highestEmission = 0;
        int year = 0;
        for(Map.Entry<Integer, Emission> entry: getEmissions().entrySet()){
            double totalEmission = entry.getValue().getCO2() + entry.getValue().getN2O() + entry.getValue().getCH4();
            if(totalEmission > highestEmission){
                highestEmission = totalEmission;
                year = entry.getKey();
            }
        }
        return year;
    }
}
