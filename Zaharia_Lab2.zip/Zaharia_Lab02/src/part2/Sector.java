package part2;

import java.util.List;
import java.util.Map;

public class Sector {
    private String name;
    private Map<Integer, Double> emissions;

    public Sector(String name, Map<Integer, Double> emissions){
        this.name = name;
        this.emissions = emissions;
    }

    public String getName(){
        return this.name;
    }

    //    public void setName(String name){ this.name = name;}

    public Map<Integer, Double> getEmissions(){
        return this.emissions;
    }

    //    public void setEmissions(Map<Integer, Double> emissions){ this.emissions = emissions};

    public int getYearWithHighestEmissions(){
        int year = 0;
        double highestEmission = 0;
        for(Map.Entry<Integer, Double> entry: this.getEmissions().entrySet()){
            if(entry.getValue() > highestEmission){
                highestEmission = entry.getValue();
                year = entry.getKey();
            }
        }
        return year;
    }

}
