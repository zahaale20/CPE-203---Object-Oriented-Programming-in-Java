package part3;

import java.util.List;
import java.util.Map;

public class Sector {
    private String name;
    private Map<Integer, Double> emissions;

    public Sector(String name, Map<Integer, Double> emissions){
        this.name = name;
        this.emissions = emissions;
    }

    public String getName(){
        return this.name;
    }

    //    public void setName(String name){ this.name = name;}

    public Map<Integer, Double> getEmissions(){
        return this.emissions;
    }

    //    public void setEmissions(Map<Integer, Double> emissions){ this.emissions = emissions};

    public int getYearWithHighestEmissions(){
        int year = 0;
        double highestEmission = 0;
        for(Map.Entry<Integer, Double> entry: this.getEmissions().entrySet()){
            if(entry.getValue() > highestEmission){
                highestEmission = entry.getValue();
                year = entry.getKey();
            }
        }
        return year;
    }

    public static Sector sectorWithBiggestChangeInEmissions(List<Sector> sectors, int startYear, int endYear) {
        double highestAvgEmission = 0;
        Sector output = null;
        for (Sector sector : sectors) {
            double avg = 0;
            for(int i = startYear; i <= endYear; i++){
                avg += sector.getEmissions().get(i);
            }
            avg = avg/(endYear - startYear);
            if(avg > highestAvgEmission){
                highestAvgEmission = avg;
                output = sector;
            }
        }
        System.out.println("Highest Increase in Emissions (" + startYear + ", " + endYear +"): " + output.getName() + ", " + highestAvgEmission);
        return output;
    }
}
