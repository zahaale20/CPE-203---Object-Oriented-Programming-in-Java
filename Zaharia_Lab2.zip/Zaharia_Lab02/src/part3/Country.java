package part3;


import java.util.List;
import java.util.Map;


public class Country {
    private String name;
    private Map<Integer, Emission> emissions;
    private int highestEmissionYear;

    public Country(String name, Map<Integer, Emission> emissions){
        this.name = name;
        this.emissions = emissions;
        this.highestEmissionYear = getYearWithHighestEmissions();
    }

    public String getName(){
        return this.name;
    }

//    public void setName(String name){ this.name = name;}

    public Map<Integer, Emission> getEmissions(){
        return this.emissions;
    }

//    public void setEmissions(Map<Integer, Emission> emissions){ this.emissions = emissions};

    public int getYearWithHighestEmissions(){
        double highestEmission = 0;
        int year = 0;
        for(Map.Entry<Integer, Emission> entry: getEmissions().entrySet()){
            double totalEmission = entry.getValue().getCO2() + entry.getValue().getN2O() + entry.getValue().getCH4();
            if(totalEmission > highestEmission){
                highestEmission = totalEmission;
                year = entry.getKey();
            }
        }
        return year;
    }

    public static Country countryWithHighestCH4InYear(List<Country> countries, int year){
        double highestCH4 = 0;
        Country output = null;
        for(Country country : countries) {
            if (country.getEmissions().get(year).getCH4() > highestCH4) {
                highestCH4 = country.getEmissions().get(year).getCH4();
                output = country;
            }
        }
        System.out.println("Highest Methane Emissions in " + year + ": " + output.getName() + ", " + highestCH4);
        return output;
    }

    public static Country countryWithHighestChangeInEmissions(List<Country> countries, int startYear, int endYear){
        double highestEmission = 0;
        Country output = null;
        for(Country country : countries){
            double startEmission = country.getEmissions().get(startYear).getCH4()
                    + country.getEmissions().get(startYear).getN2O()
                    + country.getEmissions().get(startYear).getCO2();
            double endEmission = country.getEmissions().get(endYear).getCH4()
                    + country.getEmissions().get(endYear).getN2O()
                    + country.getEmissions().get(endYear).getCO2();
            double changeInEmission = Math.abs(endEmission - startEmission);
            if (changeInEmission > highestEmission){
                highestEmission = changeInEmission;
                output = country;
            }
        }
        System.out.println("Highest Increase in Emissions (" + startYear + ", " + endYear +"): " + output.getName() + ", " + highestEmission);
        return output;
    }
}
