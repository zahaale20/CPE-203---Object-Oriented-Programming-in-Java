package part3;

public class Emission {

    private double co2;
    private double n20;
    private double ch4;

    public Emission(double co2, double n20, double ch4){
        this.co2 = co2;
        this.n20 = n20;
        this.ch4 = ch4;
    }

    public double getCO2(){
        return this.co2;
    }

    public double getN2O(){
        return this.n20;
    }

    public double getCH4(){
        return this.ch4;
    }

}
